const ingrsParent = document.querySelector('.ingredients')
//let ingrs = ingrsParent.innerHTML
ingrsList = ingrsParent.innerHTML.split(', ')
console.log(ingrsList)
let newUl = document.createElement('ul')
ingrsParent.innerHTML = ''
for (i of ingrsList){
  let newLi = document.createElement('li')
  newLi.innerHTML = i
  newUl.append(newLi)
  //console.log(newUl)
  ingrsParent.append(newUl)
}
